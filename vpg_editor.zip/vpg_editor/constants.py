UNIT_TESTING = False

SCENE_PREV_TEXTS = 'vpg_editor_text_editor_files_text'
SCENE_SHORT_TO_FULL_FILENAME = 'vpg_editor_text_editor_short_to_full_filename'

MESH_VPG_FILE_PATH = 'vpg_file_path'
MESH_DATA = 'vpg_data'
MESH_VERTEX_COUNT = 'mesh_vertex_count'
MESH_TRIANGLE_COUNT = 'mesh_triangle_count'  

BMESH_INIT_NODE_ID = 'bmesh_init_node_id'
BMESH_NODE_ID = 'bmesh_node_id'
BMESH_FACE_IDX = 'bmesh_face_indices'
